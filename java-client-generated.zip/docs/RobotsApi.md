# RobotsApi

All URIs are relative to *https://virtserver.swaggerhub.com/DEMINAEP2709/Rbot/0.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addDevice**](RobotsApi.md#addDevice) | **POST** /robots | Метод подключения нового устройства
[**getAllDevices**](RobotsApi.md#getAllDevices) | **GET** /robots | Метод получения списка всех устройств
[**getRobot**](RobotsApi.md#getRobot) | **GET** /robots/{robot_id} | Метод получения привязанного устройства по ID
[**removeRobotByNumber**](RobotsApi.md#removeRobotByNumber) | **DELETE** /robots/{robot_id} | Метод удаления робота по номеру
[**updateDevices**](RobotsApi.md#updateDevices) | **PUT** /robots | Обновление устройств

<a name="addDevice"></a>
# **addDevice**
> Robot addDevice(body)

Метод подключения нового устройства

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.RobotsApi;


RobotsApi apiInstance = new RobotsApi();
Error body = new Error(); // Error | 
try {
    Robot result = apiInstance.addDevice(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RobotsApi#addDevice");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Error**](Error.md)|  |

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getAllDevices"></a>
# **getAllDevices**
> Robots getAllDevices()

Метод получения списка всех устройств

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.RobotsApi;


RobotsApi apiInstance = new RobotsApi();
try {
    Robots result = apiInstance.getAllDevices();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RobotsApi#getAllDevices");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Robots**](Robots.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json, application/json

<a name="getRobot"></a>
# **getRobot**
> Robot getRobot(robotId)

Метод получения привязанного устройства по ID

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.RobotsApi;


RobotsApi apiInstance = new RobotsApi();
Integer robotId = 56; // Integer | Уникальный id устройства
try {
    Robot result = apiInstance.getRobot(robotId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RobotsApi#getRobot");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **robotId** | **Integer**| Уникальный id устройства |

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json, application/json

<a name="removeRobotByNumber"></a>
# **removeRobotByNumber**
> removeRobotByNumber(robotId)

Метод удаления робота по номеру

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.RobotsApi;


RobotsApi apiInstance = new RobotsApi();
Integer robotId = 56; // Integer | Уникальный id робота
try {
    apiInstance.removeRobotByNumber(robotId);
} catch (ApiException e) {
    System.err.println("Exception when calling RobotsApi#removeRobotByNumber");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **robotId** | **Integer**| Уникальный id робота |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json

<a name="updateDevices"></a>
# **updateDevices**
> Robot updateDevices(body)

Обновление устройств

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.RobotsApi;


RobotsApi apiInstance = new RobotsApi();
Robot body = new Robot(); // Robot | 
try {
    Robot result = apiInstance.updateDevices(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RobotsApi#updateDevices");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Robot**](Robot.md)|  |

### Return type

[**Robot**](Robot.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

