# Robot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**robotId** | **Integer** |  | 
**model** | **String** |  | 
**serialNumber** | **String** |  | 
**firwareVersion** | **String** |  |  [optional]
**status** | **String** |  | 
**chargeLevel** | **Integer** |  | 
